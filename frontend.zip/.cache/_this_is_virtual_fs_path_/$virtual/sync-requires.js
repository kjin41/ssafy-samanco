
// prefer default export if available
const preferDefault = m => (m && m.default) || m


exports.components = {
  "component---cache-dev-404-page-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\.cache\\dev-404-page.js")),
  "component---src-pages-404-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\src\\pages\\404.js")),
  "component---src-pages-find-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\src\\pages\\find.js")),
  "component---src-pages-login-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\src\\pages\\login.js")),
  "component---src-pages-regist-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\src\\pages\\regist.js")),
  "component---src-templates-author-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\src\\templates\\author.js")),
  "component---src-templates-index-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\src\\templates\\index.js")),
  "component---src-templates-post-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\src\\templates\\post.js")),
  "component---src-templates-tag-js": preferDefault(require("C:\\Users\\SSAFY\\1-common-project\\S06P11A502\\frontend\\src\\templates\\tag.js"))
}

